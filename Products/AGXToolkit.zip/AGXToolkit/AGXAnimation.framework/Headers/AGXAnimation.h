//
//  AGXAnimation.h
//  AGXAnimation
//
//  Created by Char Aznable on 16/2/23.
//  Copyright © 2016年 AI-CUC-EC. All rights reserved.
//

#ifndef AGXAnimation_h
#define AGXAnimation_h

#import "AGXAnimation/AGXAnimationTypes.h"

#import "AGXAnimation/UIView+AGXAnimation.h"
#import "AGXAnimation/UIWindow+AGXAnimation.h"

#endif /* AGXAnimation_h */
