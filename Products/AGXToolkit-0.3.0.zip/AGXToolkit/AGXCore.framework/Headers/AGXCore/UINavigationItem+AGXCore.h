//
//  UINavigationItem+AGXCore.h
//  AGXCore
//
//  Created by Char Aznable on 16/6/3.
//  Copyright © 2016年 AI-CUC-EC. All rights reserved.
//

#ifndef AGXCore_UINavigationItem_AGXCore_h
#define AGXCore_UINavigationItem_AGXCore_h

#import <UIKit/UIKit.h>
#import "AGXCategory.h"

@category_interface(UINavigationItem, AGXCore)
@end

#endif /* AGXCore_UINavigationItem_AGXCore_h */
