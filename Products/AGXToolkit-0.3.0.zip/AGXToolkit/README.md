# AGXToolkit

日常开发工具代码.

    pod "AGXToolkit", "~> 0.3.0"

* [压缩包下载](https://raw.githubusercontent.com/CharLemAznable/AGXToolkit/master/Products/AGXToolkit-0.3.0.zip)

##### AGXCore

  [核心依赖包](https://github.com/CharLemAznable/AGXToolkit/tree/master/AGXCore)

##### AGXRuntime

  [运行时工具包](https://github.com/CharLemAznable/AGXToolkit/tree/master/AGXRuntime)

##### AGXJson

  [JSON工具包](https://github.com/CharLemAznable/AGXToolkit/tree/master/AGXJson)

##### AGXLayout

  [视图自动布局](https://github.com/CharLemAznable/AGXToolkit/tree/master/AGXLayout)

##### AGXData

  [本地数据自动存取](https://github.com/CharLemAznable/AGXToolkit/tree/master/AGXData)

##### AGXWidget

  [页面组件](https://github.com/CharLemAznable/AGXToolkit/tree/master/AGXWidget)

##### AGXNetwork

  [网络访问](https://github.com/CharLemAznable/AGXToolkit/tree/master/AGXNetwork)

##### AGXGcode

  [二维码/条形码解析](https://github.com/CharLemAznable/AGXToolkit/tree/master/AGXGcode)
