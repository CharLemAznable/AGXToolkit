//
//  UIViewController+AGXRuntime.h
//  AGXRuntime
//
//  Created by Char Aznable on 16/2/20.
//  Copyright © 2016年 AI-CUC-EC. All rights reserved.
//

#ifndef AGXRuntime_UIViewController_AGXRuntime_h
#define AGXRuntime_UIViewController_AGXRuntime_h

#import <UIKit/UIKit.h>
#import <AGXCore/AGXCore/AGXCategory.h>

@category_interface(UIViewController, AGXRuntime)
@end

#endif /* AGXRuntime_UIViewController_AGXRuntime_h */
