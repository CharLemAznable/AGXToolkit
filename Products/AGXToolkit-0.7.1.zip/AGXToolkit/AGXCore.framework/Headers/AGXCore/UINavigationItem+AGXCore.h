//
//  UINavigationItem+AGXCore.h
//  AGXCore
//
//  Created by Char Aznable on 2016/6/3.
//  Copyright © 2016 github.com/CharLemAznable. All rights reserved.
//

#ifndef AGXCore_UINavigationItem_AGXCore_h
#define AGXCore_UINavigationItem_AGXCore_h

#import <UIKit/UIKit.h>
#import "AGXCategory.h"

@category_interface(UINavigationItem, AGXCore)
@end

#endif /* AGXCore_UINavigationItem_AGXCore_h */
