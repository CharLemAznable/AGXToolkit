//
//  UIImagePickerController+AGXCore.h
//  AGXCore
//
//  Created by Char Aznable on 17/7/27.
//  Copyright © 2017年 AI-CUC-EC. All rights reserved.
//

#ifndef AGXCore_UIImagePickerController_AGXCore_h
#define AGXCore_UIImagePickerController_AGXCore_h

#import <UIKit/UIKit.h>
#import "AGXCategory.h"

@category_interface(UIImagePickerController, AGXCore)
@end

#endif /* AGXCore_UIImagePickerController_AGXCore_h */
